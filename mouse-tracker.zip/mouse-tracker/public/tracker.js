// Function to send events to Node.js backend
function logEvent(eventType, x = null, y = null, element = null) {
  fetch("http://localhost:3000/log-event", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ eventType, x, y, element })
  });
}

// Track mouse movement
document.addEventListener("mousemove", e => {
  logEvent("move", e.clientX, e.clientY, e.target.tagName);
});

// Track clicks
document.addEventListener("click", e => {
  logEvent("click", e.clientX, e.clientY, e.target.tagName);
});

// Track scrolling
document.addEventListener("scroll", () => {
  logEvent("scroll");
});
