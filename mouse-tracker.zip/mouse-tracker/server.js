const express = require("express");
const bodyParser = require("body-parser");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public")); // serve frontend files

// ✅ MySQL connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Login@1234", // put your MySQL password here
  database: "website_tracking" // new database
});

db.connect(err => {
  if (err) {
    console.error("❌ DB Connection failed:", err);
  } else {
    console.log("✅ MySQL Connected...");
  }
});

// ✅ API to save mouse events
app.post("/log-event", (req, res) => {
  const { eventType, x, y, element } = req.body;
  const timestamp = new Date();

  db.query(
    "INSERT INTO mouse_events (event_type, x, y, element, timestamp) VALUES (?, ?, ?, ?, ?)",
    [eventType, x || null, y || null, element || null, timestamp],
    err => {
      if (err) console.error(err);
      res.sendStatus(200);
    }
  );
});

// ✅ API to fetch events
app.get("/events", (req, res) => {
  db.query("SELECT * FROM mouse_events ORDER BY id DESC", (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// ✅ Start server
app.listen(3000, () => console.log("🚀 Server running at http://localhost:3000"));
